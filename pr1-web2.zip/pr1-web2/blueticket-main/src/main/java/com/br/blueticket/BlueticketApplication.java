package com.br.blueticket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlueticketApplication {

	public static void main(String[] args) {
		SpringApplication.run(BlueticketApplication.class, args);
	}

}
