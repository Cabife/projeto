package com.br.blueticket.service.exception;

public class NonExistentOrInactiveUserException extends RuntimeException {

	private static final long serialVersionUID = 1L;

}
