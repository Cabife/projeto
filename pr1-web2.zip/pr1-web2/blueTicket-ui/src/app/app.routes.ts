import { Routes } from '@angular/router';
import { VeiculosListComponent } from './veiculos/veiculos-list/veiculos-list.component';
import { LoginFormComponent } from './security/login-form/login-form.component';
import { VeiculoRegisterComponent } from './veiculos/veiculo-register/veiculo-register.component';

export const routes: Routes = [
  { path: 'veiculos', component: VeiculosListComponent },
  { path: 'login', component: LoginFormComponent },
  { path:'veiculos/novo', component: VeiculoRegisterComponent},
  { path: '', redirectTo: '/login', pathMatch: 'full' }
];