import { Component } from '@angular/core';
import { VeiculosService } from '../veiculos.service';
import { ButtonModule } from 'primeng/button';
import { TableModule } from 'primeng/table';
import { TooltipModule } from 'primeng/tooltip';
import { CommonModule } from '@angular/common';
import { MessageComponent } from '../../shared/message/message.component';

@Component({
  selector: 'app-veiculos-list',
  standalone: true,
  imports: [
    CommonModule,
    ButtonModule,
    TableModule,
    TooltipModule,
    MessageComponent
  ],
  templateUrl: './veiculos-list.component.html',
  styleUrls: ['./veiculos-list.component.css']
})
export class VeiculosListComponent {
  veiculos = [];

  constructor(private veiculosService: VeiculosService) {}

  ngOnInit(): void {
    this.list();
  }

  list(): void {
    this.veiculosService.listByUser()
      .then(result => {
        this.veiculos = result;
      });
  }
}

