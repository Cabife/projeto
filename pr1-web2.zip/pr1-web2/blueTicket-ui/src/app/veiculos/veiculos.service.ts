import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { AuthService } from '../security/auth.service';
import { Veiculo } from '../core/model';

@Injectable({
  providedIn: 'root'
})
export class VeiculosService {

  veiculosUrl = 'http://localhost:8080/vehicle';

 email: any;

  constructor(private http: HttpClient , private auth: AuthService) { }

  async list(): Promise<any> {
    return await firstValueFrom(this.http.get(this.veiculosUrl));
  }

   async listByUser(): Promise<any> {
    this.email = this.auth.jwtPayload?.user_name;
    return await firstValueFrom(this.http.get(`${this.veiculosUrl}/user/${this.email}`));
  }

 async add(veiculo: Veiculo): Promise<Veiculo> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    const body = Veiculo.toJson(veiculo);
    return await firstValueFrom(this.http.post<Veiculo>(this.veiculosUrl, body, { headers }));
  }

}