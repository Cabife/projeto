import { Component } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { TableModule } from 'primeng/table';
import { TooltipModule } from 'primeng/tooltip';
import { SelectModule } from 'primeng/select';
import { VeiculosService } from '../veiculos.service';
import { Veiculo } from '../../core/model';
import { AuthService } from '../../security/auth.service';
import { MessageComponent } from "../../shared/message/message.component";

@Component({
  selector: 'app-veiculo-register',
  standalone: true,
  imports: [
    FormsModule,
    InputTextModule,
    ButtonModule,
    TableModule,
    TooltipModule,
    SelectModule,
    MessageComponent
],

  templateUrl: './veiculo-register.component.html',
  styleUrl: './veiculo-register.component.css'


})
export class VeiculoRegisterComponent {

veiculo: Veiculo;

  constructor(
    private veiculoService: VeiculosService,
    private auth: AuthService
  ){
    this.veiculo = new Veiculo(this.auth.jwtPayload?.user_id);
  }

  save(veiculoForm: NgForm) {
    this.veiculoService.add(this.veiculo)
      .then(() => {
        console.log('Atividade adicionada com sucesso!');
        veiculoForm.reset();
        this.veiculo = new Veiculo(this.auth.jwtPayload?.user_id);
      })
      .catch(erro => console.log(erro));
  }
  
}


