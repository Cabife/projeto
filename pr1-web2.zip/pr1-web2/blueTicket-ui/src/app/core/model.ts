

export class User {
  id!: number;
}

export class Veiculo {
  id!: number;
  placa!: '';
  modelo!: '';
  categoria!: '';
  user: any;

  constructor(user_id: number){
    this.user = new User();
    this.user.id = user_id;
  }

  static toJson(veiculo: Veiculo): any {
    return {
      id: veiculo.id,
      placa: veiculo.placa,
      modelo: veiculo.modelo,
      categoria: veiculo.categoria,
      user: veiculo.user
    }
  }

}